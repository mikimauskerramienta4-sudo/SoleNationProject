// SCRIPT GENERAL DE INTERACTIVIDAD - SOLENATION

document.addEventListener('DOMContentLoaded', () => {
    console.log("SoleNation App cargada correctamente.");

    // Manejador genérico para envíos de formularios (Contacto / Pedido)
    const formContacto = document.getElementById('form-contacto');
    const formPedido = document.getElementById('form-pedido');

    if (formContacto) {
        formContacto.addEventListener('submit', (e) => {
            e.preventDefault();
            alert("¡Gracias por tu mensaje! Nos pondremos en contacto contigo pronto.");
            formContacto.reset();
        });
    }

    if (formPedido) {
        formPedido.addEventListener('submit', (e) => {
            e.preventDefault();
            alert("¡Pedido registrado exitosamente en SoleNation! Nos comunicaremos vía WhatsApp para confirmar.");
            formPedido.reset();
        });
    }
});

// Función para filtrar productos por categoría
function filtrarProductos(categoria) {
    const productos = document.querySelectorAll('.card-product');
    
    productos.forEach(producto => {
        const catProducto = producto.getAttribute('data-categoria');
        if (categoria === 'todos' || catProducto === categoria) {
            producto.style.display = 'block';
        } else {
            producto.style.display = 'none';
        }
    });
}

// Función para calcular automáticamente el monto en pedido.html
function calcularTotal() {
    const selectProducto = document.getElementById('select-producto');
    const inputCantidad = document.getElementById('input-cantidad');
    const montoTotalSpan = document.getElementById('monto-total');

    if (selectProducto && inputCantidad && montoTotalSpan) {
        const optionSeleccionada = selectProducto.options[selectProducto.selectedIndex];
        const precio = parseFloat(optionSeleccionada.getAttribute('data-precio')) || 0;
        const cantidad = parseInt(inputCantidad.value) || 1;

        const total = precio * cantidad;
        montoTotalSpan.textContent = `S/ ${total.toFixed(2)}`;
    }
}